<?php 
define('BASE_URL', 'http://localhost/nam_pdo');
 ?>